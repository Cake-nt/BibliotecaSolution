﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca.WindowsForms
{
    internal class Program
    {
    }
}
